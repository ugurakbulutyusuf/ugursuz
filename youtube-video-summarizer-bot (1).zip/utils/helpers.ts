
/**
 * Pauses execution for a specified number of milliseconds.
 * @param ms The number of milliseconds to wait.
 * @returns A promise that resolves after the specified delay.
 */
export const sleep = (ms: number): Promise<void> => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Splits a long message into chunks of a specified maximum size, respecting line breaks.
 * @param message The message to split.
 * @param maxLength The maximum length of each chunk.
 * @returns An array of message chunks.
 */
export const splitMessage = (message: string, maxLength: number): string[] => {
    if (message.length <= maxLength) {
        return [message];
    }

    const chunks: string[] = [];
    let currentChunk = "";

    const lines = message.split('\n');

    for (const line of lines) {
        if (currentChunk.length + line.length + 1 > maxLength) {
            chunks.push(currentChunk);
            currentChunk = "";
        }
        currentChunk += line + '\n';
    }

    if (currentChunk.length > 0) {
        chunks.push(currentChunk);
    }

    // Further split any chunk that is still too long (e.g., a single long line)
    const finalChunks: string[] = [];
    for(const chunk of chunks) {
        if (chunk.length > maxLength) {
            for (let i = 0; i < chunk.length; i += maxLength) {
                finalChunks.push(chunk.substring(i, i + maxLength));
            }
        } else {
            finalChunks.push(chunk);
        }
    }


    return finalChunks;
};
