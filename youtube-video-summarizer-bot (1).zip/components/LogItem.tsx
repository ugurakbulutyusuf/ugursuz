
import React from 'react';
import { Log, LogType } from '../types';

interface LogItemProps {
    log: Log;
}

const getLogStyle = (type: LogType) => {
    switch (type) {
        case LogType.Info:
            return { icon: 'ℹ️', color: 'text-blue-300' };
        case LogType.Success:
            return { icon: '✅', color: 'text-green-400' };
        case LogType.Error:
            return { icon: '❌', color: 'text-red-400' };
        case LogType.System:
            return { icon: '⚙️', color: 'text-gray-400' };
        default:
            return { icon: '', color: '' };
    }
};

const LogItem: React.FC<LogItemProps> = ({ log }) => {
    const { icon, color } = getLogStyle(log.type);
    const time = log.timestamp.toLocaleTimeString();

    return (
        <div className={`flex items-start text-sm ${color}`}>
            <div className="flex-shrink-0 w-20 text-gray-500">[{time}]</div>
            <div className="flex-shrink-0 w-6">{icon}</div>
            <div className="flex-grow break-words">{log.message}</div>
        </div>
    );
};

export default LogItem;
