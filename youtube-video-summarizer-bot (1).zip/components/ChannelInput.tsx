
import React, { useCallback } from 'react';
import { Channel } from '../types';

interface ChannelInputProps {
    onChannelsChange: (channels: Channel[]) => void;
    disabled?: boolean;
}

const ChannelInput: React.FC<ChannelInputProps> = ({ onChannelsChange, disabled }) => {

    const handleChange = useCallback((event: React.ChangeEvent<HTMLTextAreaElement>) => {
        const text = event.target.value;
        const lines = text.split('\n');
        const channels: Channel[] = lines
            .map(line => line.trim())
            .filter(line => line.length > 0 && !line.startsWith('#'))
            .map(id => ({ id }));
        onChannelsChange(channels);
    }, [onChannelsChange]);

    return (
        <div>
            <label htmlFor="channels" className="block text-sm font-medium text-gray-300 mb-1">YouTube Channel IDs</label>
            <textarea
                id="channels"
                rows={8}
                onChange={handleChange}
                disabled={disabled}
                className="w-full bg-gray-700 border border-gray-600 text-gray-200 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50 font-mono text-sm"
                placeholder="Enter one channel ID per line.
Lines starting with # are ignored.

# AI Channels
UCbfYPyITQ-7l4upoX8nvctg
UC5A0TPwJK7XNkCUjyPXJ8Ag
"
            />
            <p className="text-xs text-gray-500 mt-1">Enter one channel ID per line. Lines starting with '#' will be treated as comments.</p>
        </div>
    );
};

export default ChannelInput;
