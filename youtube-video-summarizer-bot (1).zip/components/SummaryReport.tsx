
import React from 'react';
import { Report } from '../types';

interface SummaryReportProps {
    report: Report;
}

const SummaryReport: React.FC<SummaryReportProps> = ({ report }) => {
    const duration = report.endTime ? (report.endTime.getTime() - report.startTime.getTime()) / 1000 : 0;

    return (
        <div>
            <h2 className="text-2xl font-semibold border-b border-gray-700 pb-3 mb-4">📊 Final Summary Report</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div className="bg-gray-700 p-4 rounded-lg">
                    <p className="text-2xl font-bold text-green-400">{report.processedVideos}</p>
                    <p className="text-sm text-gray-400">Processed Videos</p>
                </div>
                <div className="bg-gray-700 p-4 rounded-lg">
                    <p className="text-2xl font-bold text-red-400">{report.failedVideos}</p>
                    <p className="text-sm text-gray-400">Failed Videos</p>
                </div>
                <div className="bg-gray-700 p-4 rounded-lg">
                    <p className="text-2xl font-bold text-blue-400">{report.totalVideosFound}</p>
                    <p className="text-sm text-gray-400">Total Videos Found</p>
                </div>
                 <div className="bg-gray-700 p-4 rounded-lg">
                    <p className="text-2xl font-bold text-purple-400">{report.scannedChannels}</p>
                    <p className="text-sm text-gray-400">Channels Scanned</p>
                </div>
            </div>
            <div className="mt-4 text-center text-gray-500">
                <p>Process started at {report.startTime.toLocaleString()} and finished at {report.endTime?.toLocaleString()}.</p>
                <p>Total duration: {duration.toFixed(2)} seconds.</p>
            </div>
        </div>
    );
};

export default SummaryReport;
