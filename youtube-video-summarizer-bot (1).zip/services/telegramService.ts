
export const sendMessage = async (botToken: string, chatId: string, text: string): Promise<void> => {
    const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
    const payload = {
        chat_id: chatId,
        text: text,
        parse_mode: 'Markdown',
    };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload),
        });

        const data = await response.json();

        if (!data.ok) {
            throw new Error(`Telegram API error: ${data.description || 'Unknown error'}`);
        }
    } catch (error) {
        console.error("Error sending message to Telegram:", error);
        if (error instanceof Error) {
            throw new Error(`Failed to send Telegram message: ${error.message}`);
        }
        throw new Error("An unknown network error occurred while contacting Telegram API.");
    }
};
