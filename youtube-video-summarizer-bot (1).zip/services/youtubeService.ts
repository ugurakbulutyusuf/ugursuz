
import { Video } from '../types';

export const getRecentVideos = async (channelId: string, apiKey: string): Promise<Video[]> => {
    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    const url = `https://www.googleapis.com/youtube/v3/search?key=${apiKey}&channelId=${channelId}&part=snippet,id&order=date&maxResults=10&type=video&publishedAfter=${twentyFourHoursAgo}`;
    
    try {
        const response = await fetch(url);
        const data = await response.json();

        if (data.error) {
            throw new Error(`YouTube API Error: ${data.error.message}`);
        }
        
        if (!data.items) {
            return [];
        }

        const videos: Video[] = data.items.map((item: any) => ({
            id: item.id.videoId,
            title: item.snippet.title,
            channelTitle: item.snippet.channelTitle,
            publishedAt: new Date(item.snippet.publishedAt),
        }));

        return videos;
    } catch (error) {
         console.error(`Failed to fetch videos for channel ${channelId}:`, error);
         if (error instanceof Error) {
            throw new Error(error.message);
         }
         throw new Error("An unknown network error occurred while contacting YouTube API.");
    }
};

/**
 * MOCK FUNCTION: Simulates fetching a YouTube video transcript.
 * This is a workaround because fetching real transcripts is not feasible from a browser.
 * @param videoId The ID of the video (unused in this mock).
 * @returns A promise that resolves to a sample transcript string.
 */
export const getTranscript = async (videoId: string): Promise<string> => {
    console.warn(`[MOCK] Fetching transcript for video ID: ${videoId}. Returning sample data.`);
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 500));

    // Return a detailed sample transcript to ensure Gemini has enough content to work with.
    return `
    Merhaba arkadaşlar, kanalıma hoş geldiniz. Bugün sizlerle en son çıkan yapay zeka araçlarını inceleyeceğiz.
    Yani, biliyorsunuz teknoloji çok hızlı ilerliyor. Özellikle **OpenAI** tarafından geliştirilen **ChatGPT** ve **DALL-E 3** modelleri inanılmaz işler başarıyor.
    Şimdi ilk aracımız, aslında bir not alma uygulaması ama çok daha fazlası. Adı **Notion AI**.
    **Notion AI** ile toplantı notlarınızı otomatik özetleyebilir, hatta içerik fikirleri üretebilirsiniz. Geçen hafta bir projede kullandım,
    biraz karışık bir görev listem vardı, onu analiz etmesini istedim. Problem şuydu: görevler arasında önceliklendirme yapamıyordum.
    Eylem olarak, **Notion AI**'a 'bu görevleri aciliyet ve önem sırasına göre düzenle' dedim.
    Sonuç olarak, bana 2 saat kazandırdı. Gerçekten inanılmaz bir şey.
    Bir diğer araç ise **Midjourney v6**. Biliyorsunuz, **Midjourney** metinden görsel üretme konusunda lider. v6 sürümü ile artık çok daha
    gerçekçi ve detaylı görseller elde edebiliyoruz. Mesela, 'a astronaut riding a horse on Mars' yazdığınızda,
    önceki versiyonlara göre çok daha tutarlı sonuçlar alıyorsunuz. Işık, gölge, her şey mükemmel.
    Son olarak, kod yazan arkadaşlar için **GitHub Copilot**'tan bahsetmek istiyorum.
    **GitHub Copilot**, siz kod yazarken size önerilerde bulunan bir yapay zeka asistanı.
    Örneğin, bir fonksiyon yazmaya başladığınızda, fonksiyonun geri kalanını sizin için tamamlayabiliyor. Bu,
    özellikle **React** veya **Python** gibi dillerde çalışırken çok zaman kazandırıyor.
    Aslında, bu araçlar sadece bir başlangıç. Gelecekte çok daha fazlasını göreceğiz.
    Videoyu beğenmeyi ve kanala abone olmayı unutmayın, hoşça kalın!
    `;
};
