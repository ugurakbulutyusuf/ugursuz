
import { GoogleGenAI } from "@google/genai";
import { GEMINI_PROMPT } from '../constants';

export const summarizeTranscript = async (transcript: string, apiKey: string): Promise<string> => {
    try {
        if (!apiKey) {
            throw new Error("Gemini API key is not provided.");
        }
        const ai = new GoogleGenAI({ apiKey });

        const fullPrompt = `${GEMINI_PROMPT}\n[${transcript}]`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: fullPrompt,
        });

        if (!response.text) {
             throw new Error("Received empty response from Gemini API.");
        }

        return response.text;
    } catch (error) {
        console.error("Error summarizing with Gemini:", error);
        if (error instanceof Error) {
            throw new Error(`Gemini API error: ${error.message}`);
        }
        throw new Error("An unknown error occurred while using Gemini API.");
    }
};
